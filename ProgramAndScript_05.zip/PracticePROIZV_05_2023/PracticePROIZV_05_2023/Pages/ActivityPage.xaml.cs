﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PracticePROIZV_05_2023.ApplicationData;
using PracticePROIZV_05_2023.DataModels;

namespace PracticePROIZV_05_2023.Pages
{
    /// <summary>
    /// Логика взаимодействия для ActivityPage.xaml
    /// </summary>
    public partial class ActivityPage : Page
    {
        public ActivityPage()
        {
            InitializeComponent();
            LoadData();
        }

        public void LoadData()
        {
            mainDataGrid.ItemsSource = NewSolutionsEntities.GetContext().Сборки.ToList();
        }

        public void LoadChosenCell()
        {
            var numberofComp = mainDataGrid.SelectedCells[0];
            var proc = mainDataGrid.SelectedCells[1];
            var gpu = mainDataGrid.SelectedCells[2];
            var drive = mainDataGrid.SelectedCells[3];
            var ram = mainDataGrid.SelectedCells[4];
            var motherboard = mainDataGrid.SelectedCells[5];
            var powersupply = mainDataGrid.SelectedCells[6];

            var comp = (numberofComp.Column.GetCellContent(numberofComp.Item) as TextBlock).Text;
            var proccesor = (proc.Column.GetCellContent(proc.Item) as TextBlock).Text;
            var gpud = (gpu.Column.GetCellContent(gpu.Item) as TextBlock).Text;
            var drived = (drive.Column.GetCellContent(drive.Item) as TextBlock).Text;
            var rams = (ram.Column.GetCellContent(ram.Item) as TextBlock).Text;
            var mom = (motherboard.Column.GetCellContent(motherboard.Item) as TextBlock).Text;
            var pow = (powersupply.Column.GetCellContent(powersupply.Item) as TextBlock).Text;
            numberofCompBox.Text = comp;
            processorBox.Text = proccesor;
            gpuBox.Text = gpud;
            hardriveBox.Text = drived;
            ramBox.Text = rams;
            mthboardBox.Text = mom;
            powersupplyBox.Text = pow;
        }

        private void mainDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadChosenCell();
        }

        private void finishBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }

        private void saveChanges_btn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Сборки userObj = new Сборки()
                {
                    Процессор = processorBox.Text,
                    Видеокарта = gpuBox.Text,
                    ОбьёмЖёсткогоДиска = int.Parse(hardriveBox.Text),
                    ОЗУ = int.Parse(ramBox.Text),
                    Материнская_плата = mthboardBox.Text,
                    Блок_питания = powersupplyBox.Text
                };
                AppConnect.model0db.Сборки.Add(userObj);
                AppConnect.model0db.SaveChanges();
                MessageBox.Show("Данные успешно добавлены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Ошибка " + Ex.Message.ToString() + "Критическая ошибка!", "Уведомления", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
