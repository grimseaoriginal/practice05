﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PracticePROIZV_05_2023.DataModels;

namespace PracticePROIZV_05_2023.ApplicationData
{
    class AppConnect
    {
        public static NewSolutionsEntities model0db;
    }
}
